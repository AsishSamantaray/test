package com.cognizant.dc.service;

import com.cognizant.dc.dto.request.DcRequest;
import com.cognizant.dc.entity.DC;
import com.cognizant.dc.exception.DcAlreadyExistException;
import com.cognizant.dc.exception.DcNotFoundException;
import com.cognizant.dc.repository.DcRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DcServiceImplTest {

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private DcRepository dcRepository;

    private Optional<DC> optionalDC;
    private DcRequest dcRequest;

    @InjectMocks
    private DcServiceImpl dcService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);


        DC dc = new DC();
        dc.setId(1l);
        dc.setDcCity("Kolkata");
        dc.setDcNumber(101l);
        dc.setDcType("Regional");

        optionalDC = Optional.of(dc);
    }

    @Test
    void check_Add_DC_Details() {
        Mockito.when(dcRepository.save(optionalDC.get())).thenReturn(optionalDC.get());
        DC actualValue = dcService.addDC(optionalDC.get());
        assertEquals(optionalDC.get().getDcCity(), actualValue.getDcCity());
        Mockito.verify(dcRepository).save(optionalDC.get());
    }

    @Test
    void throw_Exception_If_DC_Already_Exist() {
        Mockito.doReturn(optionalDC).when(dcRepository).findByDcNumber(101L);
        DC dc = optionalDC.get();
        assertThrows(DcAlreadyExistException.class, () -> {
            dcService.addDC(dc);
        });
    }

    @Test
    void check_Search_DC_From_DC_Number() {
        Mockito.when(dcRepository.findByDcNumber(Mockito.anyLong())).thenReturn(optionalDC);
        DC actualValue = dcService.searchDC(optionalDC.get().getDcNumber());
        assertEquals(optionalDC.get(), actualValue);
        Mockito.verify(dcRepository).findByDcNumber(Mockito.anyLong());
    }

    @Test
    void throw_Exception_If_DC_Number_Not_Found() {
        Mockito.when(dcRepository.findByDcNumber(Mockito.anyLong())).thenThrow(DcNotFoundException.class);
        assertThrows(DcNotFoundException.class, () -> {
            dcService.searchDC(101L);
        });
        Mockito.verify(dcRepository).findByDcNumber(Mockito.anyLong());
    }

    @Test
    void check_Update_DC_From_DC_Number() {
        Mockito.when(dcRepository.findById(1l)).thenReturn(optionalDC);
        Mockito.when(dcRepository.save(optionalDC.get())).thenReturn(optionalDC.get());
        DC actualValue = dcService.updateDC(1l, optionalDC.get());
        assertEquals(optionalDC.get(), actualValue);
        Mockito.verify(dcRepository).findById(1l);
    }

    @Test
    void throw_Exception_If_DC_Number_Not_Found_For_Update() {
        Mockito.when(dcRepository.findById(Mockito.anyLong())).thenThrow(DcNotFoundException.class);
        DC dc = optionalDC.get();
        assertThrows(DcNotFoundException.class, () -> {
            dcService.updateDC(50L, dc);
        });
        Mockito.verify(dcRepository).findById(Mockito.anyLong());
    }

    @Test
    void check_Delete_DC_From_DC_Number() {
        Mockito.when(dcRepository.findById(optionalDC.get().getId())).thenReturn(optionalDC);

        String actualValue = dcService.deleteDC(optionalDC.get().getId());
        assertEquals("DC details deleted successfully.", actualValue);
        Mockito.verify(dcRepository).delete(optionalDC.get());
    }

    @Test
    void throw_Exception_If_DC_Not_Found() {
        Mockito.when(dcRepository.findById(Mockito.anyLong())).thenThrow(DcNotFoundException.class);
        assertThrows(DcNotFoundException.class, () -> {
            dcService.deleteDC(50L);
        });
        Mockito.verify(dcRepository).findById(Mockito.anyLong());
    }

}