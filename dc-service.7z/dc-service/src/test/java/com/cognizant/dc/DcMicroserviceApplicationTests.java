package com.cognizant.dc;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DcMicroserviceApplicationTests {

	@Test
	void contextLoads() {
		Assertions.assertTrue(true);
	}

}
