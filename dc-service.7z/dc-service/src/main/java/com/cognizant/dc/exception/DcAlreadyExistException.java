package com.cognizant.dc.exception;

public class DcAlreadyExistException extends RuntimeException {
    public DcAlreadyExistException(String message) {
        super(message);
    }
}
