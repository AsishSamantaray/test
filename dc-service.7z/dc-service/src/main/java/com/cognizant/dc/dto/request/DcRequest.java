package com.cognizant.dc.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class DcRequest {
    private long dcNumber;
    private String dcCity;
    private String dcType;
}
