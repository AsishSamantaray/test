package com.cognizant.dc.service;

import com.cognizant.dc.entity.DC;
import com.cognizant.dc.exception.DcAlreadyExistException;
import com.cognizant.dc.exception.DcNotFoundException;
import com.cognizant.dc.repository.DcRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DcServiceImpl implements DcService {

    private final DcRepository dcRepository;

    @Autowired
    public DcServiceImpl(DcRepository dcRepository) {
        this.dcRepository = dcRepository;
    }

    /**
     * Method for add DC details.
     *
     * @param dc DC details
     * @return saved DC details.
     * @throws DcAlreadyExistException if DC details already present.
     */
    @Override
    public DC addDC(DC dc) {
        long dcNumber = dc.getDcNumber();
        if (dcRepository.findByDcNumber(dcNumber).isPresent()) {
            throw new DcAlreadyExistException("DC details already present.");
        } else {
            return dcRepository.save(dc);
        }
    }

    /**
     * Method for search DC details.
     *
     * @param dcNumber DC Number
     * @return DC details based on the DC Number provided.
     * @throws DcNotFoundException if DC Number not found.
     */
    @Override
    public DC searchDC(long dcNumber) {
        return dcRepository.findByDcNumber(dcNumber)
                .orElseThrow(() -> new DcNotFoundException("DC details Not found"));
    }

    /**
     * Method for update DC details.
     *
     * @param id Primary Key
     * @param dc DC details
     * @return Updated DC detail.
     * @throws DcNotFoundException if id not found.
     */
    @Override
    public DC updateDC(long id, DC dc) {
        if ((dcRepository.findById(id).isPresent())) {
            dc.setId(id);
            return dcRepository.save(dc);
        } else {
            throw new DcNotFoundException("DC Not found");
        }
    }

    /**
     * Method for delete DC details.
     *
     * @param id Primary Key
     * @throws DcNotFoundException if id not found.
     */
    @Override
    public String deleteDC(long id) {
        dcRepository.delete(dcRepository.findById(id)
                .orElseThrow(() -> new DcNotFoundException("DC Not found")));
        return "DC details deleted successfully.";
    }
}
