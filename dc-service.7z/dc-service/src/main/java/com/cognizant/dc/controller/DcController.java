package com.cognizant.dc.controller;

import com.cognizant.dc.entity.DC;
import com.cognizant.dc.service.DcService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Api(tags = "Distribution Center RESTful Services.", value = "DcController")
@RestController
@RequestMapping("/api/dc")
public class DcController {

    private final DcService dcService;

    @Autowired
    public DcController(DcService dcService) {
        this.dcService = dcService;
    }

    /**
     * Controller method for add DC details.
     *
     * @param dc DC details
     * @return saved DC details with status code 201.
     */
    @ApiOperation(value = "Add new DC details.")
    @PostMapping
    public ResponseEntity<DC> addDc(@Valid @RequestBody DC dc) {
        return new ResponseEntity<>(dcService.addDC(dc), HttpStatus.CREATED);
    }

    /**
     * Controller method for search DC details.
     *
     * @param dcNumber DC Number.
     * @return DC details based on the DC Number provided.
     */
    @ApiOperation(value = "Search for DC details.")
    @GetMapping("/bydcnumber/{dcNumber}")
    public ResponseEntity<DC> searchDc(@PathVariable long dcNumber) {
        return new ResponseEntity<>(dcService.searchDC(dcNumber), HttpStatus.OK);
    }

    /**
     * Controller method for update DC details.
     *
     * @param id Primary Key
     * @param dc DC Details
     * @return Updated DC detail.
     */
    @ApiOperation(value = "Update DC details.")
    @PutMapping("/{id}")
    public ResponseEntity<DC> updateDc(@PathVariable long id, @Valid @RequestBody DC dc) {
        return new ResponseEntity<>(dcService.updateDC(id, dc), HttpStatus.OK);
    }

    /**
     * Controller method for delete DC details.
     *
     * @param id Primary Key
     * @return Success message.
     */
    @ApiOperation(value = "Delete DC details.")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDc(@PathVariable long id) {
        return new ResponseEntity<>(dcService.deleteDC(id), HttpStatus.OK);
    }

}
