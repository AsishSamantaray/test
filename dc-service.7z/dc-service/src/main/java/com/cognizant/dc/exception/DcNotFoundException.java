package com.cognizant.dc.exception;

public class DcNotFoundException extends RuntimeException {
    public DcNotFoundException(String message) {
        super(message);
    }
}
