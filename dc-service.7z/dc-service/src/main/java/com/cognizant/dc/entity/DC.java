package com.cognizant.dc.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Data
@NoArgsConstructor
@Table(name = "dc_details")
@ApiModel(description = "Model class for Distribution Center details.")
public class DC {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "Auto generated Primary Key.", required = true, position = 1)
    private Long id;

    @ApiModelProperty(notes = "Distribution Center number.", position = 2)
    private long dcNumber;

    @NotEmpty(message = "DC City can't be empty or null.")
    @ApiModelProperty(notes = "City of Distribution Center.", position = 3)
    private String dcCity;

    @NotEmpty(message = "DC Type can't be empty or null.")
    @ApiModelProperty(notes = "Distribution Center Type.", example = "International or Regional or Imports", position = 4)
    private String dcType;
}
