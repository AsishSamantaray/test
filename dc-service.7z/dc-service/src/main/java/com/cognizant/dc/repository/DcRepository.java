package com.cognizant.dc.repository;

import com.cognizant.dc.entity.DC;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DcRepository extends JpaRepository<DC, Long> {
    Optional<DC> findByDcNumber(long dcNumber);
}
