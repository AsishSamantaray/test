package com.cognizant.dc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DcMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DcMicroserviceApplication.class, args);
	}

}
