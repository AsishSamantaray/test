package com.cognizant.dc.service;

import com.cognizant.dc.entity.DC;

public interface DcService {

    DC addDC(DC dc);

    DC searchDC(long dcNumber);

    DC updateDC(long id, DC dc);

    String deleteDC(long id);

}
