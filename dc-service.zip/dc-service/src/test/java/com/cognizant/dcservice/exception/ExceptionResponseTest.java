package com.cognizant.dcservice.exception;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExceptionResponseTest {

    @InjectMocks
    private ExceptionResponse exceptionResponse;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    final void testGetTimestamp() {
        LocalDateTime expected = LocalDateTime.now();
        exceptionResponse.setTimestamp(expected);
        LocalDateTime actual = exceptionResponse.getTimestamp();
        assertEquals(expected, actual);
    }

    @Test
    final void testGetError() {
        String expected = "Exception Response Message";
        exceptionResponse.setError(expected);
        String actual = exceptionResponse.getError();
        assertEquals(expected, actual);
    }
}