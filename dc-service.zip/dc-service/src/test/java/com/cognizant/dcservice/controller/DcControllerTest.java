package com.cognizant.dcservice.controller;

import com.cognizant.dcservice.model.request.DcRequest;
import com.cognizant.dcservice.model.response.DcResponse;
import com.cognizant.dcservice.model.response.ResponseMessage;
import com.cognizant.dcservice.service.DcService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

/**
 * Test class for Distribution Center Controller layer.
 *
 * @author Asish Samantaray
 */
@ExtendWith(SpringExtension.class)
@WebMvcTest(value = DcController.class)
@Slf4j
class DcControllerTest {

    /**
     * MockMvc Object
     */
    @Autowired
    private MockMvc mockMvc;

    /**
     * Mock object of DcService.
     */
    @MockBean
    private DcService dcService;

    private final DcResponse actualResponse = new DcResponse(
            1L, 101, "Kolkata", "Regional");
    private final String expectedResponse = "{\"id\":1,\"dcNumber\":101,\"dcCity\":\"Kolkata\",\"dcType\":\"Regional\"}";


    @Test
    void testSearchDcDetails() throws Exception {

        Mockito.when(dcService.searchDc(Mockito.anyLong())).thenReturn(actualResponse);

        MvcResult result = mockMvc.perform(get("/api/dc/number/{dcNumber}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        log.debug("testSearchDcDetails() Response: {}", result.getResponse().getContentAsString());

        JSONAssert.assertEquals(expectedResponse, result.getResponse().getContentAsString(), false);
    }

    @Test
    void testAddDcDetails() throws Exception {
        Mockito.when(dcService.addDc(Mockito.any(DcRequest.class))).thenReturn(actualResponse);

        MvcResult result = mockMvc.perform(post("/api/dc")
                .accept(MediaType.APPLICATION_JSON)
                .content(expectedResponse)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());

        JSONAssert.assertEquals(expectedResponse, response.getContentAsString(), false);
    }

    @Test
    void testUpdateDcDetails() throws Exception {
        String expReq = "{\"dcNumber\":101,\"dcType\":\"Regional\",\"dcCity\":\"Kolkata\"}";
        ResponseMessage expRes = new ResponseMessage("DC details has been updated.");

        Mockito.when(dcService.updateDc(Mockito.anyLong(), Mockito.any(DcRequest.class)))
                .thenReturn(expRes);

        MvcResult result = mockMvc.perform(put("/api/dc/{id}", 101)
                .accept(MediaType.APPLICATION_JSON)
                .content(expReq)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        JSONAssert.assertEquals("{\"message\":\"DC details has been updated.\"}",
                result.getResponse().getContentAsString(), false);
    }

    @Test
    void testDeleteDcDetails() throws Exception {
        ResponseMessage expRes = new ResponseMessage("DC details has been updated.");

        Mockito.when(dcService.deleteDc(Mockito.anyLong())).thenReturn(expRes);

        MvcResult result = mockMvc.perform(delete("/api/dc/{id}", 101)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        JSONAssert.assertEquals("{\"message\":\"DC details has been updated.\"}",
                result.getResponse().getContentAsString(), false);
    }

}