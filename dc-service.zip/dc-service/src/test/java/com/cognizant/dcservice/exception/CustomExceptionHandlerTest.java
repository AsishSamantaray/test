package com.cognizant.dcservice.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for CustomExceptionHandler.
 *
 * @author Asish Samantaray
 */
class CustomExceptionHandlerTest {

    private static final String NOT_FOUND_MESSAGE = "DC Details Not found with provided ID.";

    private static final String ALREADY_EXISTS_MESSAGE = "DC details already present.";

    @Mock
    private MethodArgumentNotValidException mockedException;
    @Mock
    private BindingResult result;

    @InjectMocks
    private CustomExceptionHandler customExceptionHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testHandleAllException() {
        ResponseEntity<Object> response = customExceptionHandler.handleAllException(Mockito.mock(Exception.class));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode(), "The error should be 500 INTERNAL SERVER ERROR");
    }

    @Test
    void testHandleDcNotFoundException() {
        DcNotFoundException dcNotFoundEx = new DcNotFoundException(NOT_FOUND_MESSAGE);
        ResponseEntity<Object> response = customExceptionHandler.handleDcNotFoundException(dcNotFoundEx);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode(), "The error should be 404 Not Found");
    }

    @Test
    void testHandleMethodArgumentNotValid() {

        Mockito.doReturn(this.result).when(this.mockedException).getBindingResult();
        Mockito.doReturn(this.getDummyFieldErrors()).when(this.result).getFieldErrors();

        final ResponseEntity<Object> responseEntity = customExceptionHandler.handleMethodArgumentNotValid(this.mockedException,
                Mockito.mock(HttpHeaders.class), HttpStatus.BAD_REQUEST, Mockito.mock(WebRequest.class));
        Assertions.assertNotNull(responseEntity);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode(), "The error should be 400 Bad Request");
    }

    @Test
    void testHandleDcAlreadyExistException() {
        DcAlreadyExistsException dcAlreadyExistsEx = new DcAlreadyExistsException(ALREADY_EXISTS_MESSAGE);
        ResponseEntity<Object> response = customExceptionHandler.handleDcAlreadyExistException(dcAlreadyExistsEx);
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    void checkResponse() {
        ExceptionResponse noError = new ExceptionResponse(LocalDateTime.now(), "No Error");
        assertEquals(noError.getTimestamp().getDayOfMonth(), LocalDateTime.now().getDayOfMonth());

    }

    private List<FieldError> getDummyFieldErrors() {

        final List<FieldError> fieldErrors = new ArrayList<>();
        fieldErrors.add(new FieldError("objectName", "field", "defaultMessage"));
        return fieldErrors;
    }
}