package com.cognizant.dcservice.service;

import com.cognizant.dcservice.entity.DcEntity;
import com.cognizant.dcservice.exception.DcAlreadyExistsException;
import com.cognizant.dcservice.exception.DcNotFoundException;
import com.cognizant.dcservice.model.request.DcRequest;
import com.cognizant.dcservice.model.response.DcResponse;
import com.cognizant.dcservice.model.response.ResponseMessage;
import com.cognizant.dcservice.repository.DcRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class DcServiceImplTest {


    @InjectMocks
    private DcServiceImpl dcService;

    @Mock
    private DcRepository dcRepository;

    private DcEntity dcEntity;
    private DcRequest dcRequest;
    private DcResponse dcResponse;

    private static final String UPDATE_MESSAGE = "DC details has been deleted successfully.";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        dcEntity = new DcEntity();

        dcRequest = new DcRequest();
        dcRequest.setDcCity("Kolkata");
        dcRequest.setDcNumber(101L);
        dcRequest.setDcType("Regional");

        dcEntity.setId(1L);
        dcEntity.setDcNumber(101L);
        dcEntity.setDcCity("Kolkata");
        dcEntity.setDcType("Regional");

        dcResponse = new DcResponse(1L, 101L, "Kolkata", "Regional");
        dcResponse.setId(1L);
        dcResponse.setDcNumber(101L);
        dcResponse.setDcCity("Kolkata");
        dcResponse.setDcType("Regional");

    }

    @Test
    void testAddDcReturnExceptionIfDcAlreadyPresent() {
        Mockito.when(dcRepository.findByDcNumber(101)).thenReturn(dcEntity);
        assertThrows(DcAlreadyExistsException.class, () -> dcService.addDc(dcRequest));
    }

    @Test
    void testAddDcWillSaveDcDetailsToDB() {
        Mockito.when(dcRepository.save(Mockito.any(DcEntity.class))).thenReturn(dcEntity);
        DcResponse dcResponse = dcService.addDc(dcRequest);
        assertEquals(dcResponse.getDcCity(), dcRequest.getDcCity(), "DC City must be same.");
    }

    @Test
    void testSearchDcReturnExceptionIfDcNotFound() {
        long dcNumber = Mockito.anyLong();
        Mockito.when(dcRepository.findByDcNumber(dcNumber)).thenReturn(null);
        assertThrows(DcNotFoundException.class, () -> dcService.searchDc(dcNumber));
    }

    @Test
    void testSearchDcWillReturnDcDetails() {
        long dcNumber = Mockito.anyLong();
        Mockito.when(dcRepository.findByDcNumber(dcNumber)).thenReturn(dcEntity);
        new DcResponse(1L, 101L, "Kolkata", "Regional");
        DcResponse dcResponse = dcService.searchDc(dcNumber);
        assertEquals(dcResponse.getDcType(), dcRequest.getDcType(), "DC Type must be same.");
    }

    @Test
    void testDeleteDcWillReturnSuccessMessage() {
        long id = Mockito.anyLong();
        Mockito.when(dcRepository.findById(id)).thenReturn(Optional.of(dcEntity));
        dcRepository.delete(dcEntity);
        ResponseMessage message = dcService.deleteDc(id);
        assertEquals(UPDATE_MESSAGE, message.getMessage());
    }

    @Test
    void testDeleteDcWillReturnExceptionIfIdNotFound() {
        Mockito.when(dcRepository.findById(Mockito.anyLong())).thenThrow(DcNotFoundException.class);
        assertThrows(DcNotFoundException.class, () -> dcService.deleteDc(50L));
        Mockito.verify(dcRepository).findById(Mockito.anyLong());
    }

    @Test
    void testDcResponse() {
        DcResponse dr = new DcResponse(1L, 101L, "Kolkata", "Regional");
        dr.setId(dcResponse.getId());
        dr.setDcNumber(dcResponse.getDcNumber());
        dr.setDcCity(dcResponse.getDcCity());
        dr.setDcType(dcResponse.getDcType());

        assertEquals(dr.getDcType(), dcResponse.getDcType());
    }
}