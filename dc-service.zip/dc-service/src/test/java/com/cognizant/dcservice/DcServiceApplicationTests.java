package com.cognizant.dcservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class DcServiceApplicationTests {

    /**
     * Test method for Main method.
     */
    @Test
    void testMainMethod() {
        DcServiceApplication.main(new String[]{

        });
        assertTrue(true, "Always True");
    }

}
