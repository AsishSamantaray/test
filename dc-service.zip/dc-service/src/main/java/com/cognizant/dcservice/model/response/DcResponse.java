package com.cognizant.dcservice.model.response;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Model class for response.
 *
 * @author Asish Samantaray
 */
@Setter
@Getter
@AllArgsConstructor
public class DcResponse {
    private Long id;
    private long dcNumber;
    private String dcCity;
    private String dcType;
}
