package com.cognizant.dcservice.model.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Model class for Message response.
 *
 * @author Asish Samantaray
 */
@Getter
@Setter
@AllArgsConstructor
public class ResponseMessage {
    private final String message;
}
