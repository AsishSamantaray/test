package com.cognizant.dcservice.service;

import com.cognizant.dcservice.entity.DcEntity;
import com.cognizant.dcservice.model.request.DcRequest;
import com.cognizant.dcservice.model.response.DcResponse;
import com.cognizant.dcservice.model.response.ResponseMessage;

/**
 * Service interface for DC Microservice.
 *
 * @author Asish Samantaray
 */
public interface DcService {
    DcResponse addDc(DcRequest dcRequest);

    DcResponse searchDc(long dcNumber);

    ResponseMessage updateDc(long id, DcRequest dcRequest);

    ResponseMessage deleteDc(long id);

    DcEntity convertToEntity(DcRequest dcRequest);

}
