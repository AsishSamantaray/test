package com.cognizant.dcservice.exception;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Custom Exception Handler class for DC Microservice.
 *
 * @author Asish Samantaray
 */
@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Exception Handler method for INTERNAL_SERVER_ERROR.
     *
     * @param ex Exception
     * @return Exception message with status code 500.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllException(Exception ex) {
        ExceptionResponse response = new ExceptionResponse(LocalDateTime.now(), ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Exception Handler method for InValid Method Argument.
     *
     * @param ex      Exception
     * @param headers Headers
     * @param status  Status Code
     * @param request WebRequest
     * @return Exception message with status code 400.
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());

        List<String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(Collectors.toList());

        body.put("errors", errors);
        return new ResponseEntity<>(body, headers, HttpStatus.BAD_REQUEST);
    }

    /**
     * Exception Handler method for DcNotFoundException.
     *
     * @param ex DcNotFoundException
     * @return Exception message with status code 404.
     */
    @ExceptionHandler(DcNotFoundException.class)
    public ResponseEntity<Object> handleDcNotFoundException(DcNotFoundException ex) {
        ExceptionResponse response = new ExceptionResponse(LocalDateTime.now(), ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    /**
     * Exception Handler method for DcAlreadyExistException.
     *
     * @param ex DcAlreadyExistException
     * @return Exception message with status code 400.
     */
    @ExceptionHandler(DcAlreadyExistsException.class)
    public ResponseEntity<Object> handleDcAlreadyExistException(DcAlreadyExistsException ex) {
        ExceptionResponse response = new ExceptionResponse(LocalDateTime.now(), ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
    }
}