package com.cognizant.dcservice.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Exception Response model class.
 *
 * @author Asish Samantaray
 */
@Setter
@Getter
@AllArgsConstructor
public class ExceptionResponse {
    private LocalDateTime timestamp;
    private String error;
}