package com.cognizant.dcservice.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * Model class for Request Body.
 *
 * @author Asish Samantaray
 */
@Data
@NoArgsConstructor
@ApiModel(description = "Model class for Distribution Center details.")
public class DcRequest {

    @ApiModelProperty(notes = "Distribution Center number.")
    @NotNull(message = "DC Number can't be empty.")
    private Long dcNumber;

    @NotEmpty(message = "DC City can't be empty or null.")
    @ApiModelProperty(notes = "Distribution Center Type.", example = "International or Regional or Imports")
    private String dcType;

    @NotEmpty(message = "DC Type can't be empty or null.")
    @ApiModelProperty(notes = "City of Distribution Center.")
    private String dcCity;
}
