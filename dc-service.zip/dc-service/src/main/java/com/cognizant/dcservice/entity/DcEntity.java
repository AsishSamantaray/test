package com.cognizant.dcservice.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * Entity class for DC Microservice.
 *
 * @author Asish Samantaray
 */
@Data
@Entity
@NoArgsConstructor
@Table(name = "dc_details")
public class DcEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long dcNumber;
    private String dcCity;
    private String dcType;
}
