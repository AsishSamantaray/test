package com.cognizant.dcservice.controller;

import com.cognizant.dcservice.model.request.DcRequest;
import com.cognizant.dcservice.model.response.DcResponse;
import com.cognizant.dcservice.model.response.ResponseMessage;
import com.cognizant.dcservice.service.DcService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Controller class for DC Microservice.
 *
 * @author Asish Samantaray
 */
@RestController
@RequestMapping("/api/dc")
public class DcController {

    private final DcService dcService;

    @Autowired
    public DcController(DcService dcService) {
        this.dcService = dcService;
    }

    /**
     * Controller method for add DC details.
     *
     * @param dcRequest DC details
     * @return saved DC details with status code 201.
     */
    @ApiOperation(value = "Add new DC details.")
    @PostMapping
    public ResponseEntity<DcResponse> addDcDetails(@Valid @RequestBody DcRequest dcRequest) {
        return new ResponseEntity<>(dcService.addDc(dcRequest), HttpStatus.CREATED);
    }

    /**
     * Controller method for search DC details.
     *
     * @param dcNumber DC Number.
     * @return DC details based on the DC Number provided.
     */
    @ApiOperation(value = "Search for DC details.")
    @GetMapping("/number/{dcNumber}")
    public ResponseEntity<DcResponse> searchDcDetails(@PathVariable Long dcNumber) {
        return new ResponseEntity<>(dcService.searchDc(dcNumber), HttpStatus.OK);
    }

    /**
     * Controller method for update DC details.
     *
     * @param id        Primary Key
     * @param dcRequest DC Details
     * @return Updated Success message.
     */
    @ApiOperation(value = "Update DC details.")
    @PutMapping("/{id}")
    public ResponseEntity<ResponseMessage> updateDcDetails(@PathVariable Long id, @RequestBody DcRequest dcRequest) {
        return new ResponseEntity<>(dcService.updateDc(id, dcRequest), HttpStatus.OK);
    }

    /**
     * Controller method for delete DC details.
     *
     * @param id Primary Key
     * @return Deleted Success message.
     */
    @ApiOperation(value = "Delete DC details.")
    @DeleteMapping("/{id}")
    public ResponseEntity<ResponseMessage> deleteDcDetails(@PathVariable Long id) {
        return new ResponseEntity<>(dcService.deleteDc(id), HttpStatus.OK);
    }
}
