package com.cognizant.dcservice.exception;

/**
 * Exception class for DcNotFoundException.
 *
 * @author Asish Samantaray
 */
public class DcNotFoundException extends RuntimeException {
    public DcNotFoundException(String message) {
        super(message);
    }
}
