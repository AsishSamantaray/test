package com.cognizant.dcservice.exception;

/**
 * Exception class for DcAlreadyExistsException.
 *
 * @author Asish Samantaray
 */
public class DcAlreadyExistsException extends RuntimeException {
    public DcAlreadyExistsException(String message) {
        super(message);
    }
}
