package com.cognizant.dcservice.service;

import com.cognizant.dcservice.entity.DcEntity;
import com.cognizant.dcservice.exception.DcAlreadyExistsException;
import com.cognizant.dcservice.exception.DcNotFoundException;
import com.cognizant.dcservice.model.request.DcRequest;
import com.cognizant.dcservice.model.response.DcResponse;
import com.cognizant.dcservice.model.response.ResponseMessage;
import com.cognizant.dcservice.repository.DcRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Service Implementation class for DC Microservice.
 *
 * @author Asish Samantaray
 */
@Service
public class DcServiceImpl implements DcService {

    private final DcRepository dcRepository;

    @Autowired
    public DcServiceImpl(DcRepository dcRepository) {
        this.dcRepository = dcRepository;
    }

    /**
     * Method for adding DC details.
     *
     * @param dcRequest DC details
     * @return saved DC details.
     * @throws DcAlreadyExistsException If DC details already present.
     */
    @Override
    public DcResponse addDc(DcRequest dcRequest) {
        DcEntity dcEntity = convertToEntity(dcRequest);
        long dcNumber = dcEntity.getDcNumber();
        DcEntity dcDetails = dcRepository.findByDcNumber(dcNumber);
        if (dcDetails != null) {
            throw new DcAlreadyExistsException("DC details already present.");
        } else {
            DcEntity savedDC = dcRepository.save(dcEntity);
            return new DcResponse(savedDC.getId(),
                    savedDC.getDcNumber(), savedDC.getDcCity(), savedDC.getDcType());
        }
    }

    /**
     * Method for search DC details.
     *
     * @param dcNumber DC Number
     * @return DC details based on the DC Number provided.
     * @throws DcNotFoundException if DC Number not found.
     */
    @Override
    public DcResponse searchDc(long dcNumber) {
        DcEntity dcDetails = dcRepository.findByDcNumber(dcNumber);
        if (dcDetails == null) {
            throw new DcNotFoundException("DC Details Not found with provided DC Number.");
        } else {
            return new DcResponse(dcDetails.getId(),
                    dcDetails.getDcNumber(), dcDetails.getDcCity(), dcDetails.getDcType());
        }
    }

    /**
     * Method for update DC details.
     *
     * @param id        Primary Key
     * @param dcRequest DC details
     * @return Updated DC detail.
     * @throws DcNotFoundException if id not found.
     */
    @Override
    public ResponseMessage updateDc(long id, DcRequest dcRequest) {
        Optional<DcEntity> optionalEntity = dcRepository.findById(id);
        if (optionalEntity.isPresent()) {
            DcEntity currDC = optionalEntity.get();
            currDC.setId(id);
            currDC.setDcNumber(dcRequest.getDcNumber());
            currDC.setDcCity(dcRequest.getDcCity());
            currDC.setDcType(dcRequest.getDcType());
            dcRepository.save(currDC);
            return new ResponseMessage("DC details has been updated.");
        } else {
            throw new DcNotFoundException("DC Details Not found with provided ID.");
        }
    }

    /**
     * Method for delete DC details.
     *
     * @param id Primary Key
     * @throws DcNotFoundException if id not found.
     */
    @Override
    public ResponseMessage deleteDc(long id) {
        Optional<DcEntity> optionalEntity = dcRepository.findById(id);
        if (optionalEntity.isPresent()) {
            dcRepository.delete(optionalEntity.get());
            return new ResponseMessage("DC details has been deleted successfully.");
        } else {
            throw new DcNotFoundException("DC Details Not found with provided ID.");
        }
    }

    /**
     * Method for converting DTO to Entity.
     *
     * @param dcRequest DC Details
     * @return Converted Entity.
     */
    @Override
    public DcEntity convertToEntity(DcRequest dcRequest) {
        DcEntity dcEntity = new DcEntity();
        dcEntity.setDcType(dcRequest.getDcType());
        dcEntity.setDcCity(dcRequest.getDcCity());
        dcEntity.setDcNumber(dcRequest.getDcNumber());
        return dcEntity;
    }

}
