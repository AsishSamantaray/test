package com.cognizant.dcservice.repository;

import com.cognizant.dcservice.entity.DcEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for DC Microservice.
 *
 * @author Asish Samantaray
 */
@Repository
public interface DcRepository extends JpaRepository<DcEntity, Long> {
    DcEntity findByDcNumber(long dcNumber);

}
